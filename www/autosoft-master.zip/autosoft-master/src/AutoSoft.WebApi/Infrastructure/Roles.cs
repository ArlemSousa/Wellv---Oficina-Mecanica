﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AutoSoft.WebApi.Infrastructure
{
    public static class Roles
    {
        public const string Admin = "Admin";
        public const string User = "User";
    }
}