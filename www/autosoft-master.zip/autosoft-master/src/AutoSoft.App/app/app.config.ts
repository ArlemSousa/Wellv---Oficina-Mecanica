export class AppConfig {
    public static API_ENDPOINT = 'http://localhost:55111';
}