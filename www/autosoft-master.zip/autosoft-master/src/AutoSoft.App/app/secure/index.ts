﻿export * from './home/home.component';
export * from './clientes/cliente.component';
export * from './secure.routes';