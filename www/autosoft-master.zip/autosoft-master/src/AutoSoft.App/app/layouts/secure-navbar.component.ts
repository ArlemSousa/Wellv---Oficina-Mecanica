import { Component } from "@angular/core";

@Component({
    templateUrl: 'secure-navbar.component.html',
    styleUrls: ['secure-navbar.component.css']
})
export class SecureNavBarComponent { }