import { Component } from '@angular/core';

@Component({
    selector: 'layout-secure',
    templateUrl: 'secure.component.html'
})
export class SecureComponent { }