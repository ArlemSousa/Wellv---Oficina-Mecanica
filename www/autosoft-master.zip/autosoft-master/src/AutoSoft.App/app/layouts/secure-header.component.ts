import { Component } from "@angular/core";

@Component({
    templateUrl: 'secure-header.component.html'
})
export class SecureHeaderComponent { }