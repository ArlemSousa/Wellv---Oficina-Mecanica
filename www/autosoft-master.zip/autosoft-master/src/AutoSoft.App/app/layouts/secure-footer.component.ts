import { Component } from '@angular/core';

@Component({
    templateUrl: 'secure-footer.component.html'
})
export class SecureFooterComponent { }