﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoSoft.Domain.CoreBC
{
    public enum UnidadeMedida
    {
        Unidades = 1,
        Litros = 2
    }
}
