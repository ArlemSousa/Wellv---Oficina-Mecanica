﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoSoft.Infrastructure.Util
{
    public static class Constantes
    {
        public static class MensagensValidacao
        {
            public const string CampoObrigatorio = "O campo {0} é obrigatório";
        }
    }
}
