# autosoft
Sistema de gestão de oficina mecânica

Stack utilizada:

* C# 6.0
* ASP.NET 4.6.2
* Angular 2
* Bootstrap
* Web API 2
* OWIN
* Entity Framework
* SQL Server Compact
* AutoFac
* AutoMapper

Arquitetura utilizada

* DDD
* CQRS
